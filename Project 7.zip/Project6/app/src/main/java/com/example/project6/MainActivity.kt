package com.example.mypet

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import okhttp3.Headers

class MainActivity : AppCompatActivity() {

    private val characters = mutableListOf<Character>()
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: CharacterAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.characterRecyclerView)
        adapter = CharacterAdapter(characters)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        fetchCharacters()
    }

    private fun fetchCharacters() {
        val client = AsyncHttpClient()
        val url = "https://rickandmortyapi.com/api/character"

        Log.d("RM", "Fetching characters...")

        client[url, object : JsonHttpResponseHandler() {

            override fun onSuccess(
                statusCode: Int,
                headers: Headers,
                json: JsonHttpResponseHandler.JSON
            ) {
                Log.d("RM", "Success: $json")

                val results = json.jsonObject.getJSONArray("results")
                characters.clear()

                for (i in 0 until results.length()) {
                    val obj = results.getJSONObject(i)

                    val character = Character(
                        name = obj.getString("name"),
                        species = obj.getString("species"),
                        status = obj.getString("status"),
                        imageUrl = obj.getString("image")
                    )
                    characters.add(character)
                }

                Log.d("RM", "Loaded ${characters.size} characters")
                adapter.notifyDataSetChanged()
            }

            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                errorResponse: String,
                throwable: Throwable?
            ) {
                Log.e("RM_ERROR", "Failed ($statusCode): $errorResponse", throwable)

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "API failed. Check internet / Logcat.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }]
    }
}
