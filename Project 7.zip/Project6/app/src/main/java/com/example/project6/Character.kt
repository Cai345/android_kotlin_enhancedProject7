package com.example.mypet

data class Character(
    val name: String,
    val species: String,
    val status: String,
    val imageUrl: String
)
